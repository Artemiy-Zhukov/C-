﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApplication333
{
    public partial class Form1 : Form
    {
         

        public string[] arrName()
        {
            string[] arr;
            using (SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|newDB1.mdf;Integrated Security=True;Connect Timeout=30"))
            {
                conn.Open();
                var command0 = new SqlCommand("SELECT name from user",
                                                conn);
                using (SqlDataReader reader = command0.ExecuteReader())
                {
                    var list = new List<string>();
                    while (reader.Read())
                    {
                        list.Add(reader.GetString(0));
                    }
                    arr = list.ToArray();
                }
                
            }
            return arr;
        }

        public string[] arrNotes()
        {
            string[] arrnotes;
            using (SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|newDB1.mdf;Integrated Security=True;Connect Timeout=30"))
            {
                conn.Open();
                var command00 = new SqlCommand("SELECT title from notes",
                                                conn);
                using (SqlDataReader reader = command00.ExecuteReader())
                {
                    var list = new List<string>();
                    while (reader.Read())
                    {
                        list.Add(reader.GetString(0));
                    }
                    arrnotes = list.ToArray();
                }

            }
            return arrnotes;
        }

       

        public void addUser(string login, string password, string mail, string pol1)
        {
            using (SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|newDB1.mdf;Integrated Security=True;Connect Timeout=30"))
            {
                conn.Open();
                var command001 = new SqlCommand("INSERT INTO users VALUES (@name1,@pass1,@mail1,@pol11);",
                                                conn);
                command001.Parameters.AddWithValue("name1", login);
                command001.Parameters.AddWithValue("pass1", password);
                command001.Parameters.AddWithValue("mail1", mail);
                command001.Parameters.AddWithValue("pol11", pol1);
                command001.ExecuteNonQuery();
            }
        }

        public void addNote(string title, string zapis, int id)
        {
            using (SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|newDB1.mdf;Integrated Security=True;Connect Timeout=30"))
            {
                conn.Open();
                var command002 = new SqlCommand("INSERT INTO notes VALUES (@a,@b,@c);",
                                                conn);
                command002.Parameters.AddWithValue("a", title);
                command002.Parameters.AddWithValue("b", zapis);
                command002.Parameters.AddWithValue("c", id);
                command002.ExecuteNonQuery();
            }
        }

        public string readNote(string title)
        {
            string text = "";
            using (SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|newDB1.mdf;Integrated Security=True;Connect Timeout=30"))
            {
                conn.Open();
                var command005 = new SqlCommand("SELECT content from notes where title=@a",
                                                conn);
                command005.Parameters.AddWithValue("a", title);
                using (SqlDataReader reader = command005.ExecuteReader())
                {
                    reader.Read();
                   text = reader.GetString(0);

                }
            }
            return text;
        }
    

        public bool checkNote(string[] arr, string name)
        {
            bool check = true;
            for (int i = 0; i < arr.Length; i++)
            {
                if (arr[i] == name)
                {
                    check = true;
                    break;
                }
                else
                {
                    check = false;
                }
            }
            return check;
        }

        public void delNote(string title)
        {   
            using (SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|newDB1.mdf;Integrated Security=True;Connect Timeout=30"))
            {
                conn.Open();
                var command003 = new SqlCommand("delete from notes where title=@a",
                                                conn);
                command003.Parameters.AddWithValue("a", title);
                command003.ExecuteNonQuery();
            }
        }

        public void editNote(string title, string content)
        {
            using (SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|newDB1.mdf;Integrated Security=True;Connect Timeout=30"))
            {
                conn.Open();
                var command004 = new SqlCommand("update notes set content=@b where title=@a",
                                                conn);
                command004.Parameters.AddWithValue("a", title);
                command004.Parameters.AddWithValue("b", content);
                command004.ExecuteNonQuery();
            }
        }

        public string getpass(string name)
        {
            string CurrentPass;
            using (SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|newDB1.mdf;Integrated Security=True;Connect Timeout=30"))
            {
                conn.Open();
                var command001 = new SqlCommand("SELECT pass from users where name=@imya;",
                                                conn);
                command001.Parameters.AddWithValue("imya",name);
                using (SqlDataReader reader = command001.ExecuteReader())
                {
                    reader.Read();
                    CurrentPass = reader.GetString(0);
                }
            }
            return CurrentPass;
        }


        public Int32 getID(string name)
        {
            int idUser;
            using (SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|newDB1.mdf;Integrated Security=True;Connect Timeout=30"))
            {
                conn.Open();
                var command001 = new SqlCommand("SELECT id from users where name=@imya ",
                                                conn);
                command001.Parameters.AddWithValue("imya", name);
                using (SqlDataReader reader = command001.ExecuteReader())
                {
                    reader.Read();
                    idUser = reader.GetInt32(0);
                }
                return idUser;
            }
        }

        public bool checkName(string[] arr, string name)
        {
            bool check = true;
            for (int i = 0; i < arr.Length; i++)
            {
                if (arr[i] == name)
                {
                    check = true;
                    break;
                }
                else
                {
                    check = false;
                }
            }
            return check;
        }

                /* bool check =true;
                for (int i = 0; i < arr.Length; i++)
                {
                    if (arr[i] == name)
                    { check = true; }
                    else { check = false; }
                }
                return check;  */
                 

        public void Vhod(string name)
        {
            int id = getID(name);
            dataGridView1.Visible = true;
            label4.Visible = true;
            button3.Visible = true;
            button4.Visible = true;
            button5.Visible = true;
            
            using (SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|newDB1.mdf;Integrated Security=True;Connect Timeout=30"))
                {
                    conn.Open();
                    var command002 = new SqlCommand("select * from notes where user_id=@id;", conn);
                    command002.Parameters.AddWithValue("id", id);

                    SqlDataAdapter data = new SqlDataAdapter(command002);
                    DataTable note = new DataTable();
                    data.Fill(note);
                    dataGridView1.DataSource = note;

                }
           
            }
        
        public bool checkPass(string name,string pass)
        {
            bool check = true;
            string ex_pass = getpass(name);
            if (pass == ex_pass)
            {
                check = true;
            }
            else
            {
                check = false;
            }
            return check;
        }

        public Form1()
        {
            InitializeComponent();

            label4.Visible = false;
            button3.Visible = false;
            button4.Visible = false;
            button5.Visible = false;
            dataGridView1.Visible = false;
            label5.Visible = false;
            label6.Visible = false;
            label7.Visible = false;
            label8.Visible = false;
            textBox5.Visible = false;
            textBox6.Visible = false;
            textBox7.Visible = false;
            listBox1.Visible = false;
            button6.Visible = false;
            richTextBox1.Visible = false;
            textBox8.Visible = false;
            label9.Visible = false;
            button7.Visible = false;
            button8.Visible = false;
            button9.Visible = false;
            button10.Visible = false;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            using (SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|newDB1.mdf;Integrated Security=True;Connect Timeout=30"))
            {

                conn.Open();
                textBox1.Text = (conn.State.ToString());
                conn.Close();
            }
           
        }

   /*      private void button1_Click(object sender, EventArgs e)
        {
            string name = (textBox2.Text);
            string pass = (textBox3.Text);
            string Ex_pass = getpass(name);
            int id_user = getID(name);
            string[] arrname = arrName();
            bool check1 = checkName(arrname, name);
            bool check2 = checkPass(Ex_pass, pass);



            using (SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|newDB1.mdf;Integrated Security=True;Connect Timeout=30"))
            {
                conn.Open();
                var command0 = new SqlCommand("SELECT pass FROM users where name=@i;", conn);
                var command1 = new SqlCommand("SELECT Id FROM users where name=@i;", conn);
                command0.Parameters.AddWithValue("i", name);
                command1.Parameters.AddWithValue("i", name);

                using (SqlDataReader reader = command0.ExecuteReader())
                {
                    reader.Read();
                    e_pass = reader.GetString(0);
                }
                using (SqlDataReader reader1 = command1.ExecuteReader())
                {
                    reader1.Read();
                    id_user = reader1.GetInt32(0);
                }
                conn.Close();
            }

            if (pass == e_pass)
            {
                dataGridView1.Visible = true;
                label4.Visible = true;
                button3.Visible = true;
                button4.Visible = true;
                button5.Visible = true;
                textBox4.Text = getID(name).ToString();

                using (SqlConnection conn1 = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|newDB1.mdf;Integrated Security=True;Connect Timeout=30"))
                {
                    conn1.Open();
                    var command2 = new SqlCommand("select * from notes where user_id=@id;", conn1);
                    command2.Parameters.AddWithValue("id", id_user);

                    SqlDataAdapter data = new SqlDataAdapter(command2);
                    DataTable note = new DataTable();
                    data.Fill(note);
                    dataGridView1.DataSource = note;

                }
            }
            else
            {
                textBox2.Text = ("неверное имя");
                textBox3.Text = ("неверный пароль");

            }
        }        */

        private void button1_Click(object sender, EventArgs e)
        {
            label5.Visible = false;
            label6.Visible = false;
            label7.Visible = false;
            label8.Visible = false;
            button6.Visible = false;
            textBox5.Visible = false;
            textBox6.Visible = false;
            textBox7.Visible = false;
            listBox1.Visible = false;

        
            string Ex_pass = "";
            string name = (textBox2.Text);
            string pass = (textBox3.Text);
            string[] arrname = arrName();
            bool check1 = checkName(arrname, name);
            textBox1.Text = name;

            if (check1 == true)
            {
                Ex_pass = getpass(name);
            }

            else { }
            if (pass == Ex_pass && name!="")
            {
                Vhod(name);
                textBox4.Text = (name);
                textBox2.Text = ("");
                textBox3.Text = ("");
            }
            else
            {
                textBox2.Text = ("неверное имя");
                textBox3.Text = ("неверный пароль");
            }
          
  


        }

        private void button2_Click(object sender, EventArgs e)
        {
            label5.Visible = true;
            label6.Visible = true;
            label7.Visible = true;
            label8.Visible = true;
            textBox5.Visible = true;
            textBox6.Visible = true;
            textBox7.Visible = true;
            listBox1.Visible = true;
            button6.Visible = true;
            label4.Visible = false;
            button3.Visible = false;
            button4.Visible = false;
            button5.Visible = false;
            dataGridView1.Visible = false;
            textBox2.Text = ("");
            textBox3.Text = ("");
            textBox8.Visible = false;
                label9.Visible = false;
            button8.Visible = false;
            button10.Visible = false;
            richTextBox1.Visible = false;
            button7.Visible = false;
            textBox1.Text = "";
            button9.Visible = false;

        }

        private void button6_Click(object sender, EventArgs e)
        {
           
            button2.Visible = false;
            string a = textBox5.Text;
            string b = textBox6.Text;
            string c = textBox7.Text;
            string d=listBox1.Text;
            string[] x = arrName();
            bool check = checkName(x,a);

            if (a != "" && b != "" && check == false)
            {
                addUser(a, b, c, d);
                textBox4.Text = "ПОЛЬЗОВАТЕЛЬ ДОБАВЛЕН";
                textBox5.Visible = false;
                textBox6.Visible = false;
                textBox7.Visible = false;
                label5.Visible = false;
                label6.Visible = false;
                label7.Visible = false;
                label8.Visible = false;
                button2.Visible = false;
                button6.Visible = false;
                listBox1.Visible = false;
            }
            else if (check==true)
            {
                textBox4.Text = "юзер с таким именим уже есть";
                textBox5.Text = ("");
                textBox6.Text = ("");
                textBox7.Text = ("");
            }
            else
            {
                textBox4.Text = "Введите даннЫЕ";
                textBox5.Text = ("");
                textBox6.Text = ("");
                textBox7.Text = ("");
            }

        }

        private void button3_Click(object sender, EventArgs e)
        {
            button8.Visible = false;
            richTextBox1.Visible = true;
            textBox8.Visible = true;
            label9.Visible = true;
            button6.Visible = false;
            button7.Visible =true;
            button9.Visible = false;
            richTextBox1.Text = "";
            button10.Visible = false;

        }

        private void button7_Click(object sender, EventArgs e)
        {
            string x = richTextBox1.Text;
            string y = textBox8.Text;
            string z = textBox1.Text;
            string[] arrnotes = arrNotes();
            bool check = checkNote(arrnotes, y);
            int id = getID(z);


            if (x != "" && check == false)
            {
                addNote(y, x, id);
                textBox4.Text = ("ЗАПИСЬ ДОБАВЛЕНА");
                using (SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|newDB1.mdf;Integrated Security=True;Connect Timeout=30"))
                {
                    conn.Open();
                    var command002 = new SqlCommand("select * from notes where user_id=@id;", conn);
                    command002.Parameters.AddWithValue("id", id);

                    SqlDataAdapter data = new SqlDataAdapter(command002);
                    DataTable note = new DataTable();
                    data.Fill(note);
                    dataGridView1.DataSource = note;

                }
                richTextBox1.Visible = false;
                textBox8.Visible = false;
                label9.Visible = false;


                button7.Visible = false;
            }

            else if (check == true)
            {
                textBox4.Text = ("ЗАПИСКА С ТАКИМ ИМЕНЕМ УЖЕ ЕСТЬ");
            }
            else { textBox4.Text = ("НЕТ НАЗВАНИЯ"); } 
        }

        private void button4_Click(object sender, EventArgs e)
        {
            textBox8.Visible = true;
            button8.Visible = true;
            label9.Visible = true;
            textBox8.Text ="";
            richTextBox1.Visible = false;
            button7.Visible = false;
            button9.Visible = false;
            button10.Visible = false;

        }

        private void button8_Click(object sender, EventArgs e)
        {
            string nameNote = textBox8.Text;
            string name = textBox1.Text;
            int  id = getID(name);
            string[] arrnotes = arrNotes();
            bool x = checkNote(arrnotes, nameNote);
            

               if (nameNote != "" && x == true)
                 {
                     delNote(nameNote);
                     textBox4.Text = ("ЗАПИСЬ УДАЛЕНА");
                textBox8.Text = "";

                     using (SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|newDB1.mdf;Integrated Security=True;Connect Timeout=30"))
                     {
                         conn.Open();
                         var command002 = new SqlCommand("select * from notes where user_id=@id;", conn);
                         command002.Parameters.AddWithValue("id", id);

                         SqlDataAdapter data = new SqlDataAdapter(command002);
                         DataTable note = new DataTable();
                         data.Fill(note);
                         dataGridView1.DataSource = note;

                     }
                     textBox8.Visible = false;
                     label9.Visible = false;
                     button8.Visible = false;
                     textBox8.Visible = true;
               
                 }
                 else if (x == false || nameNote == "")
                 { textBox4.Text = ("ЗАПИСИ С ТАКИМ ИМЕНЕМ НЕТ"); }              

        }

        private void button5_Click(object sender, EventArgs e)
        {
            textBox8.Visible = true;
            textBox8.Text = "";
            label9.Visible = true;
            button7.Visible = false;
            button8.Visible = false;
            button9.Visible = true;
            richTextBox1.Visible =false;
            button10.Visible = false;
        }

        private void button9_Click(object sender, EventArgs e)
        {
            string b = textBox1.Text;
            string a = textBox8.Text;
          string[]  arrnotes = arrNotes();
            bool check = checkNote(arrnotes, a);
            richTextBox1.Visible = true;
            if (check == true)
            {
                richTextBox1.Text= readNote(a);
                textBox8.Text = "";
                button10.Visible = true;
               
                label10.Text = a;
                
            }
            else {
                textBox4.Text = ("ТАКОЙ ЗАПИСИ НЕТ!!!!!!!!");
                richTextBox1.Visible = false;
                textBox8.Text = "";
                textBox1.Text = b;
            }
        }

        private void button10_Click(object sender, EventArgs e)
        {
            string title = label10.Text;
            string name = textBox1.Text;
            int id = getID(name);
            string content = richTextBox1.Text;
            editNote(title, content);
            textBox4.Text = "ИЗМЕНЕНИЯ СОХРАНЕНЫ";
            using (SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|newDB1.mdf;Integrated Security=True;Connect Timeout=30"))
            {
                conn.Open();
                var command002 = new SqlCommand("select * from notes where user_id=@id;", conn);
                command002.Parameters.AddWithValue("id", id);

                SqlDataAdapter data = new SqlDataAdapter(command002);
                DataTable note = new DataTable();
                data.Fill(note);
                dataGridView1.DataSource = note;

            }

        }
    }
}

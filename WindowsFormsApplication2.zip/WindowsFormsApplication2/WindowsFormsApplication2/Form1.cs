﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace WindowsFormsApplication2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            this.Text = "Сотрудники";
            this.textBox1.Text = "Id отдела";
            textBox2.Text = "Сотрудники";

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            using (var connection = new OleDbConnection(
                   @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=Database11.accdb"))
            {
                connection.Open();
                var command2 = new OleDbCommand("SELECT * FROM Departments",
                                                connection);

                using (OleDbDataReader reader = command2.ExecuteReader())
                {
                    while (reader.Read())
                    {

                        richTextBox2.AppendText(string.Format("id  {0}\t{1}\t;{2}\n",
                            reader.GetInt32(0).ToString(),
                            reader.GetString(1),
                            reader.GetString(2)));
                    }
                }
            }
            using (var connection1 = new OleDbConnection(
                   @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=Database11.accdb"))
            {
                connection1.Open();
                var command2 = new OleDbCommand("SELECT * FROM Departments",
                                                connection1);
                OleDbDataAdapter data = new OleDbDataAdapter(command2);
                DataTable department = new DataTable();
                data.Fill(department);
                dataGridView2.DataSource = department;
                connection1.Close();

            }


            }

        private void button1_Click_1(object sender, EventArgs e)
        {

            using (var connection = new OleDbConnection
                (
                  @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=Database11.accdb"))
            {
                int otdel = Convert.ToInt32(this.textBox1.Text);
                connection.Open();
                textBox3.Text = (connection.State.ToString());
                textBox2.Text = (otdel.ToString());

                var command = new OleDbCommand("SELECT Stuff.Name , Stuff.Surname, Stuff.Department , TariffScale.Grade FROM Stuff , TariffScale  Where Stuff.Grade=TariffScale.id AND Stuff.Department=@number",
                                                 connection);
                command.Parameters.AddWithValue("number", otdel);
                using (OleDbDataReader reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {

                        richTextBox1.Text = (
                                 reader.GetString(0) + ' ' +
                                    reader.GetString(1) + " отдел " +
                                    reader.GetInt32(2).ToString() + " разряд " +
                        reader.GetInt32(3).ToString());

                    }
                }
            }
            using (var connection2 = new OleDbConnection
                 (
                   @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=Database11.accdb"))
            {
                int otdel = Convert.ToInt32(this.textBox1.Text);
                connection2.Open();

                var command = new OleDbCommand("SELECT Stuff.Name , Stuff.Surname, Stuff.Department , TariffScale.Grade FROM Stuff , TariffScale  Where Stuff.Grade=TariffScale.id AND Stuff.Department=@number",
                                                 connection2);
                command.Parameters.AddWithValue("number", otdel);
                OleDbDataAdapter data = new OleDbDataAdapter(command);
                DataTable employees = new DataTable();
                data.Fill(employees);
                dataGridView1.DataSource = employees;
                connection2.Close();
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }
    }
}

    /*  class data
      {
          static void Main(string[] args)
          {

             static void Main(string[] args)
          {

              using (var connection = new OleDbConnection(
                  @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=Database11.accdb"))
              {


                  Console.WriteLine(connection.State.ToString());
                  connection.Open();
               /*   var command2 = new OleDbCommand("INSERT INTO Departments values ('6','grew','3438888852')",
                                                  connection);
                  command2.ExecuteNonQuery();

                  var command4 = new OleDbCommand("Delete from Departments where id=6 ",
                                                  connection);
                  command4.ExecuteNonQuery();  


                  Console.WriteLine(connection.State.ToString());
                  var command = new OleDbCommand("SELECT * FROM Departments",
                                                  connection);

                  using (OleDbDataReader reader = command.ExecuteReader())
                  {
                      while (reader.Read())
                      {
                          Console.WriteLine(string.Format("{0};\t{1}",
                              reader.GetString(1),
                              reader.GetString(2)));

                          Console.WriteLine();
                          Console.WriteLine("Введите id отдела");
                          string answer = Console.ReadLine();

                          var command32 = new OleDbCommand("SELECT Stuff.Name , Stuff.Surname, Stuff.Department , TariffScale.Grade FROM Stuff , TariffScale  Where Stuff.Grade=TariffScale.id AND Stuff.Department=@number", connection);
                          command32.Parameters.AddWithValue("number", answer);
                          using (OleDbDataReader reader12 = command32.ExecuteReader())
                          {
                              while (reader12.Read())
                              {
                                  Console.WriteLine(
                                      reader12.GetString(0) + ' ' +
                                         reader12.GetString(1) + " отдел-" +
                                          reader12.GetInt32(2) + " разряд-" +
                                          reader12.GetInt32(3));
                              }
                          }

                          connection.Close();
                          Console.WriteLine();
                      }
                  }
              }
              Console.ReadKey();
          } }   */
